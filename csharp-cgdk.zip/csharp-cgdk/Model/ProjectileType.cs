namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model {
    public enum ProjectileType {
        MagicMissile,
        FrostBolt,
        Fireball,
        Dart
    }
}