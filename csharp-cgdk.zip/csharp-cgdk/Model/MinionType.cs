namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model {
    public enum MinionType {
        OrcWoodcutter,
        FetishBlowdart
    }
}