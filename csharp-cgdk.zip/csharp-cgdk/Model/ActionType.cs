namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model {
    public enum ActionType {
        None,
        Staff,
        MagicMissile,
        FrostBolt,
        Fireball,
        Haste,
        Shield
    }
}