namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk.Model {
    public enum StatusType {
        Burning,
        Empowered,
        Frozen,
        Hastened,
        Shielded
    }
}